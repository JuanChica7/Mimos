-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-05-2024 a las 23:03:52
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `spa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE `cita` (
  `name_mascota` varchar(45) NOT NULL,
  `edad` int(3) NOT NULL,
  `genero` varchar(45) NOT NULL,
  `raza` varchar(45) NOT NULL,
  `propietario` varchar(45) NOT NULL,
  `cc` varchar(25) NOT NULL,
  `num_cc` int(12) NOT NULL,
  `email` varchar(45) NOT NULL,
  `celular` int(11) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `servicio` varchar(45) NOT NULL,
  `fechas` date NOT NULL,
  `hora` time NOT NULL,
  `id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cita`
--

INSERT INTO `cita` (`name_mascota`, `edad`, `genero`, `raza`, `propietario`, `cc`, `num_cc`, `email`, `celular`, `direccion`, `servicio`, `fechas`, `hora`, `id`) VALUES
('max', 2, 'macho', 'pitbull', 'juan', 'cc', 22, 'chicacorjuan0304@gmail.com', 32332, 'rivera', '[orte', '2024-05-29', '03:00:00', 1),
('sam', 2, 'macho', 'pitbull', 'manuel', 'cc', 23222, 'juan_chicaco@fet.edu.co', 123456, 'cll 7b #5-07', 'corte', '2024-05-29', '16:39:00', 2),
('wilmer', 2, 'macho', 'chihuahua', 'juan', 'cc', 2, 'yosoyfet@fet.edu.co', 1212, 'cll 7b #5-07', 'corte', '2024-05-30', '18:59:00', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_user` varchar(2500) NOT NULL,
  `contrasena_user` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_user`, `contrasena_user`) VALUES
(1, 'admin', 'admin2');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`,`contrasena_user`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cita`
--
ALTER TABLE `cita`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
