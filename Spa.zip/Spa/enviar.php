<?php

// Se utiliza para llamar al archivo que contiene la conexión a la base de datos
require 'php/conexion.php';

// Validamos que el formulario y que el botón de envío hayan sido presionados
if(isset($_POST['citas'])) {

    // Obtener los valores enviados por el formulario
    $name_mascota = $_POST['name_mascota'];
    $edad = $_POST['edad'];
    $genero = $_POST['genero'];
    $raza = $_POST['raza'];
    $propietario = $_POST['propietario'];
    $cc = $_POST['cc'];
    $num_cc = $_POST['num_cc'];
    $email = $_POST['email'];
    $celular = $_POST['celular'];
    $direccion = $_POST['direccion'];
    $servicio = $_POST['servicio'];
    $fechas = $_POST['fechas'];
    $hora = $_POST['hora'];

    // Insertamos los datos en la base de datos
    $sql = "INSERT INTO cita (name_mascota, edad, genero, raza, propietario, cc, num_cc, email, celular, direccion, servicio, fechas, hora) VALUES ('$name_mascota', '$edad', '$genero', '$raza', '$propietario', '$cc', '$num_cc', '$email', '$celular', '$direccion', '$servicio', '$fechas', '$hora')";
    $resultado = mysqli_query($conexion, $sql);

    if($resultado) {
        // Inserción correcta
        echo "¡Se insertaron los datos correctamente!";
    } else {
        // Inserción fallida
        echo "¡No se puede insertar la información!"."<br>";
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Verificar si la clave 'email' existe en el array $_POST antes de usarla
$email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : '';

// Imprimir el valor del email para depuración
echo "Email: $email <br>";

if(!empty($email)){

    $asunto = 'Citas Mimos y patitas';

    $cuerpo = '
    <html>
        <head>
            <title>Confirmacion de Cita</title>
        </head>
        <body>
            <h1>Muchas gracias por agendar su cita</h1>
            <p>Cita confirmada.</p>
        </body>
    </html>
    ';

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=utf-8\r\n";
    $headers .= "From: ejemplo@tu-dominio.com\r\n"; // Asegúrate de usar una dirección de correo válida
    $headers .= "Return-Path: ejemplo@tu-dominio.com\r\n";

    if(mail($email, $asunto, $cuerpo, $headers)){
        echo "Email enviado correctamente";
        
    } else {
        echo "Error al enviar el email";
    }

} else {
    echo "No se pudo enviar, falta el email";
}

?>


