
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MIMOS & PATITAS</title>
    <link rel="stylesheet" href="styles.css" />

    <style>
        button {
	font-size: 2rem;
	padding: 0.8em 2em;
	background-color: #000;
	border: 3px solid pink;
	border-radius: 1em;
	color: #fff;
	font-weight: bolder;
	transition: cubic-bezier(0.68, -0.55, 0.265, 1.55) 0.4s;
	box-shadow: -5px 5px 0px 0px pink;
  }

  .bbb{
    
    text-align: center;
  }
  
  
  button:hover {
	transform: translate(5px, -5px);
  }
    </style>
</head>

<body>
    <header>
        <div class="container-hero">
            <div class="container hero">
                <div class="container-logo">
                    <img src="img/Logo.png" alt="Descripción de la imagen" class="logo-img">
                    <h1 class="logo"><a href="index.html">Mimos & Patitas</a></h1>
                </div>
                <div class="container-user">
                    <a href="login.html"><i class="fa-solid fa-user"></i></a>
                </div>
            </div>
        </div>

        <div class="container-navbar">
            <nav class="navbar container">
                <i class="fa-solid fa-bars"></i>
                <ul class="menu">
                    <li><a href="#">Inicio</a></li>
                    <li><a href="index.html#servicios">Servicios</a></li>
                    <li><a href="#contacto">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <form action="enviar.php" method="POST" >
        <div class="form-container">
            <div class="container">
                <h2>CITAS</h2>
                <div class="form-group">
                    <label for="nombre_mascota">Nombre de la mascota:</label>
                    <input type="text" name="name_mascota" id="nombre_mascota" pattern="[A-Za-zÁÉÍÓÚáéíóú\s]+" required>
                </div>

                <div class="form-group">
                    <label for="edad_mascota">Edad de la mascota:</label>
                    <input type="number" name="edad" id="edad_mascota" min="0" required>
                </div>

                <div class="form-group">
                    <label for="genero">Género:</label>
                    <select name="genero" id="genero" required>
                        <option value="">Seleccione</option>
                        <option value="macho">Macho</option>
                        <option value="hembra">Hembra</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="raza">Raza de la mascota:</label>
                    <input type="text" name="raza" id="raza" pattern="[A-Za-zÁÉÍÓÚáéíóú\s]+" required>
                </div>

                <div class="form-group">
                    <label for="nombre_propietario">Nombre del propietario:</label>
                    <input type="text" name="propietario" id="nombre_propietario" pattern="[A-Za-zÁÉÍÓÚáéíóú\s]+"
                        required>
                </div>

                <div class="form-group">
                    <label for="tipo_documento">Tipo de Documento:</label>
                    <select name="cc" id="tipo_documento" required>
                        <option value="">Seleccione</option>
                        <option value="cc">Cédula de Ciudadanía</option>
                        <option value="id">Tarjeta de Identidad</option>
                        <option value="ce">Cédula de Extranjería</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="numero_documento">Número de documento:</label>
                    <input type="number" name="num_cc" id="num_cc" required>
                </div>
                <div class="form-group">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" name="email" id="email" required>
                </div>

                <div class="form-group">
                    <label for="numero_contacto">Número de contacto:</label>
                    <input type="tel" name="celular" id="numero_contacto" pattern="[0-9]+" required>
                </div>

                <div class="form-group">
                    <label for="direccion">Dirección completa:</label>
                    <textarea name="direccion" id="direccion" required></textarea>
                </div>

                <div class="form-group">
                    <label for="foto_mascota">Foto carnet de vacunas:</label>
                    <input type="file" name="foto_mascota" id="foto_mascota" accept="image/*" required>
                </div>

                <div class="form-group">
                    <label for="servicio">Selecciona el servicio:</label>
                    <select name="servicio" id="servicio" required>
                        <option value="corte">Corte de pelo</option>
                        <!-- Añade más opciones según sea necesario -->
                    </select>
                </div>
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <input type="date" class="form-control" id="fecha" name="fechas" required>
                </div>
                <div class="form-group">
                    <label for="hora">Hora</label>
                    <input type="time" class="form-control" id="hora" name="hora" required>
                </div>
                <div id="mensaje" style="display: none;">
                    <p id="mensajeTexto"></p>
                </div>
                <br>
                <div class="checkbox-container">
                    <input type="checkbox" id="autorizacion" required>
                    <div class="checkbox-text required">Autorizo que mi mascota sea sometida a un proceso de estética,
                        respetando las libertades y leyes que amparan a los animales ley 1774 de 2016, entendiendo que este
                        proceso puede generar estrés en mi mascota y se puede presentar el riesgo en alguna medida de paro
                        cardíaco respiratorio. Confirmo que el personal que me atiende es claro en la información que me otorgó
                        acerca del tema, y que de llegar a ser necesario autorizo se pueda realizar RCP (Reanimación Cardio
                        Pulmonar) para atender una eventual emergencia.
                    </div>
                </div>
                <div class="bbb">
                <div class="form-group">
                    <button type="submit" name="citas" value="Enviar">Enviar</button>
                </div>
                </div>
                
            </div>
        </div>
    </form>

    <footer id="contacto" class="footer">
        <div class="container container-footer">
            <div class="menu-footer">
                <div class="contact-info">
                    <p class="title-footer">Información de Contacto</p>
                    <ul>
                        <li>Cl. 13a #35-11</li>
                        <li>Teléfono: 313 3165619</li>
                        <li>Email: valeja1718@gmail.com</li>
                        <li><a href="#">Políticas de Privacidad</a></li>
                    </ul>
                    <br>
                    <div class="social-icons">
                        <a href="https://www.facebook.com/Goyipet" target="_blank" rel="noopener noreferrer">
                            <span class="facebook">
                                <i class="fa-brands fa-facebook-f"></i>
                            </span>
                        </a>
                        <a href="https://api.whatsapp.com/send?phone=573133165619&text=Hola%2C%20me%20gustar%C3%ADa%20adquirir%20m%C3%A1s%20informaci%C3%B3n%20%F0%9F%A4%97"
                            target="_blank" rel="noopener noreferrer">
                            <span class="wsp">
                                <i class="fa-brands fa-whatsapp"></i>
                            </span>
                        </a>
                    </div>
                </div>
                <br>
                <div class="copyright">
                    <p>
                        Desarrollado por estudiantes de Software &copy; 2024
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://kit.fontawesome.com/81581fb069.js" crossorigin="anonymous"></script>

    

   
</body>

</html>



