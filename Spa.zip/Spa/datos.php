<?php
// Se utiliza para llamar al archivo que contiene la conexión a la base de datos
require 'php/conexion.php';

// Consulta para obtener los datos de la base de datos
$sql = "SELECT * FROM cita";
$resultado = mysqli_query($conexion, $sql);

// Verificamos si la consulta devuelve resultados
if (mysqli_num_rows($resultado) > 0) {
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Mostrar Datos</title>
        <link rel='stylesheet' href='styles.css'>

        <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .containerr {
            width: 90%;
            margin: 20px ;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .styled-table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 18px;
            text-align: left;
            border-radius: 8px 8px 0 0;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .styled-table thead tr {
            background-color: #f8c6d4;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
        }
        
        
        
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        
        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3e1e9;
        }
        
        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #f8c6d4;
        }
        
        .styled-table tbody tr:hover {
            background-color: #f1d4e5;
            cursor: pointer;
        }
        
        h2 {
            text-align: center;
            color: #e78aa1;
        }
        
        

        </style>

    </head>
    <body>
        <header>
            <div class='container-hero'>
                <div class='container hero'>
                    <div class='container-logo'>
                        <img src='img/Logo.png' alt='Descripción de la imagen' class='logo-img'>
                        <h1 class='logo'><a href='index.html'>Mimos & Patitas</a></h1>
                    </div>
                    <div class='container-user'>
                        <a href='login.html'><i class='fa-solid fa-user'></i></a>
                    </div>
                </div>
            </div>

            <div class='container-navbar'>
                <nav class='navbar container'>
                    <i class='fa-solid fa-bars'></i>
                    <ul class='menu'>
                        <li><a href='index.html'>Inicio</a></li>
                        <li><a href='index.html#servicios'>Servicios</a></li>
                        <li><a href='#contacto'>Contacto</a></li>
                    </ul>
                </nav>
            </div>
        </header>

        <div class='containerr'>
            <h2 >Datos de las Citas</h2>
            <table class='styled-table'>
                <thead>
                    <tr>
                        <th>Nombre de la Mascota</th>
                        <th>Edad</th>
                        <th>Género</th>
                        <th>Raza</th>
                        <th>Nombre del Propietario</th>
                        <th>Tipo de Documento</th>
                        <th>Número de Documento</th>
                        <th>Correo Electrónico</th>
                        <th>Número de Contacto</th>
                        <th>Dirección</th>
                        <th>Servicio</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                    </tr>
                </thead>
                <tbody>";

    // Mostrar los datos en la tabla
    while($fila = mysqli_fetch_assoc($resultado)) {
        echo "<tr>
                <td>{$fila['name_mascota']}</td>
                <td>{$fila['edad']}</td>
                <td>{$fila['genero']}</td>
                <td>{$fila['raza']}</td>
                <td>{$fila['propietario']}</td>
                <td>{$fila['cc']}</td>
                <td>{$fila['num_cc']}</td>
                <td>{$fila['email']}</td>
                <td>{$fila['celular']}</td>
                <td>{$fila['direccion']}</td>
                <td>{$fila['servicio']}</td>
                <td>{$fila['fechas']}</td>
                <td>{$fila['hora']}</td>
            </tr>";
    }

    echo "        </tbody>
            </table>
        </div>

        <footer id='contacto' class='footer'>
            <div class='container container-footer'>
                <div class='menu-footer'>
                    <div class='contact-info'>
                        <p class='title-footer'>Información de Contacto</p>
                        <ul>
                            <li>Cl. 13a #35-11</li>
                            <li>Teléfono: 313 3165619</li>
                            <li>Email: valeja1718@gmail.com</li>
                            <li><a href='#'>Políticas de Privacidad</a></li>
                        </ul>
                        <br>
                        <div class='social-icons'>
                            <a href='https://www.facebook.com/Goyipet' target='_blank' rel='noopener noreferrer'>
                                <span class='facebook'>
                                    <i class='fa-brands fa-facebook-f'></i>
                                </span>
                            </a>
                            <a href='https://api.whatsapp.com/send?phone=573133165619&text=Hola%2C%20me%20gustar%C3%ADa%20adquirir%20m%C3%A1s%20informaci%C3%B3n%20%F0%9F%A4%97'
                                target='_blank' rel='noopener noreferrer'>
                                <span class='wsp'>
                                    <i class='fa-brands fa-whatsapp'></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <br>
                    <div class='copyright'>
                        <p>
                            Desarrollado por estudiantes de Software &copy; 2024
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    </body>
    </html>";
} else {
    echo "No hay datos disponibles.";
}







?>
