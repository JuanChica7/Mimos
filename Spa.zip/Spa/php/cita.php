<?php
// Se utiliza para llamar al archivo que contine la conexion a la base de datos
require 'php/conexion.php';

// Validamos que el formulario y que el boton registro haya sido presionado
if(isset($_POST['enviar'])) {

// Obtener los valores enviados por el formulario
$name_mascota = $_POST['name_mascota'];
$edad = $_POST['edad'];
$genero = $_POST['genero'];
$raza = $_POST['raza'];
$propietario = $_POST['propietario'];
$cc = $_POST['cc'];
$num_cc = $_POST['num_cc'];
$email = $_POST['email'];
$celular = $_POST['celular'];
$direccion = $_POST['direccion'];
$servicio = $_POST['servicio'];
$fechas = $_POST['fechas'];
$hora = $_POST['hora'];

// Insertamos los datos en la base de datos
$sql = "INSERT INTO cita ( name_mascota, edad, genero, raza, propietario, cc, num_cc, email, celular, direccion, servicio, fechas, hora  ) VALUES ( '$name_mascota', '$edad', '$genero', '$raza', '$propietario', '$cc', '$num_cc', '$email ', '$celualar', '$direccion', '$servicio', '$fechas', '$hora' )";
$resultado = mysqli_query($conexion,$sql);
	if($resultado) {
		// Iserción correcta
		echo "¡Se insertaron los datos correctamente!";
	} else {
		// Iserción fallida
		echo "¡No se puede insertar la informacion!"."<br>";
		echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
	}
}
?>